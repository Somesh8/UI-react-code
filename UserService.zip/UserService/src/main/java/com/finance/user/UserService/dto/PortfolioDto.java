package com.finance.user.UserService.dto;

import java.util.List;

import lombok.Data;

@Data
public class PortfolioDto {
	private int id;
	
	private List<AssetDto> assets;
	private int userId;
}
