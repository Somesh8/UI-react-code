package com.finance.user.UserService.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.finance.user.UserService.UserRepository;
import com.finance.user.UserService.dto.PortfolioDto;
import com.finance.user.UserService.dto.UserDto;
import com.finance.user.UserService.model.User;
import com.finance.user.UserService.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private RestTemplate rTemplate;
	
	
	@Override
	public List<User> getAllUsers() {
		return userRepository.findAll();
	}

	@Override
	public User getUser(int id) {
		return userRepository.findById(id).get();
	}

	@Override
	public User saveUser(User data) {
		return userRepository.save(data);
	}
	
	
	public UserDto getAllAssetInformation(int uid) {
		
		User u = userRepository.findById(uid).get();
		ResponseEntity<PortfolioDto[]> listPortfolio = rTemplate.getForEntity("http://localhost:8086/portfolio/user/"+uid, PortfolioDto[].class);
		List<PortfolioDto> body = List.of(listPortfolio.getBody()) ;
		
		return UserDto.builder()
				.port(body)
				.id(uid)
				.name(u.getName())
				.build();
	}

}














