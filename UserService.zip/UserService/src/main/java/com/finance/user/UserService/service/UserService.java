package com.finance.user.UserService.service;

import java.util.List;

import com.finance.user.UserService.model.User;

public interface UserService {

	List<User> getAllUsers();

	User getUser(int id);

	User saveUser(User data);

}
