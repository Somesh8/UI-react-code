package com.finance.portfolio.PortfolioService.service;

import java.util.List;

import com.finance.portfolio.PortfolioService.model.Portfolio;

public interface PortfolioService {
	List<Portfolio> getAllPortfolioes();

	Portfolio getPortfolio(int id);

	List<Portfolio> getPortfolioesByUserId(int userId);

	Portfolio savePortfolio(Portfolio port);
}
