package com.finance.portfolio.PortfolioService.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.finance.portfolio.PortfolioService.model.Portfolio;

public interface Portfoliorepository extends JpaRepository<Portfolio, Integer>{

	List<Portfolio> findByUserId(int userId);

}
