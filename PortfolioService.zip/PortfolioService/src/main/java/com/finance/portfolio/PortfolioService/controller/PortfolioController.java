package com.finance.portfolio.PortfolioService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.finance.portfolio.PortfolioService.model.Portfolio;
import com.finance.portfolio.PortfolioService.service.PortfolioService;

@RestController
@RequestMapping("/portfolio")
public class PortfolioController {

	
	@Autowired
	private PortfolioService portfolioService;
	
	@GetMapping
	public List<Portfolio> getUsers() {
		return portfolioService.getAllPortfolioes();
	}
	 
	@GetMapping("/{pId}")
	public Portfolio getPortfolioFromId(@PathVariable final int pId) {
		
		return portfolioService.getPortfolio(pId);
	}
	
	@GetMapping("/user/{uId}")
	public List<Portfolio> getPortfoliosFromuserId(@PathVariable final int uId) {
		
		return portfolioService.getPortfolioesByUserId(uId);
	}
	
	@PostMapping
	public Portfolio savePortfolio(@RequestBody Portfolio port) {
		
		return portfolioService.savePortfolio(port);
	}
}
