package com.finance.portfolio.PortfolioService.dto;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PortfolioDto {

	private int id;
	
	private List<AssetDto> assets;
	private int userId;
}
