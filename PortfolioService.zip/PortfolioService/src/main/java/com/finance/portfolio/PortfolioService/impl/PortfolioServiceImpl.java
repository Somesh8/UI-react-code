package com.finance.portfolio.PortfolioService.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.finance.portfolio.PortfolioService.model.AssetDto;
import com.finance.portfolio.PortfolioService.model.Portfolio;
import com.finance.portfolio.PortfolioService.repository.Portfoliorepository;
import com.finance.portfolio.PortfolioService.service.PortfolioService;
import com.finance.portfolio.PortfolioService.dto.PortfolioDto;
@Service
public class PortfolioServiceImpl implements PortfolioService {

	@Autowired
	private Portfoliorepository portfolioRepository;
	
	@Autowired
	private RestTemplate rTemplate;
	
	@Override
	public List<Portfolio> getAllPortfolioes() {
		return portfolioRepository.findAll();
	}

	@Override
	public Portfolio getPortfolio(int id) {
		// TODO Auto-generated method stub
		return portfolioRepository.findById(id).get();
	}

	@Override
	public List<Portfolio> getPortfolioesByUserId(int userId) {
		// TODO Auto-generated method stub
		return portfolioRepository.findByUserId(userId);
	}

	@Override
	public Portfolio savePortfolio(Portfolio port) {
		// TODO Auto-generated method stub
		return portfolioRepository.save(port);
	}
	
	public List<PortfolioDto> getUserPortdfolioWithAssets(int userId) {
		
		List<PortfolioDto> resp;
		List<Portfolio> listPf = portfolioRepository.findByUserId(userId);
		
		for (Portfolio portfolio : listPf) {
			// get Asset associated with portfolia
			ResponseEntity<AssetDto[]> listAssets = rTemplate.getForEntity("http://localhost:8087/asset/"+portfolio.getId(), AssetDto[].class);
			List<AssetDto> assetList = List.of(listAssets.getBody());
			PortfolioDto ports = PortfolioDto.builder()
					.assets(assetList)
					.id(userId)
					.build();
			resp.add(ports);
		}
		
		return resp;
	}

}
