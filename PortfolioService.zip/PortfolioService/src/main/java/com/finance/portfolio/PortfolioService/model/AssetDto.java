package com.finance.portfolio.PortfolioService.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AssetDto {
	private int id;
	private int quantity;
	private String type;// - can be stocks, bonds, and other assets
	private double price;
	private String date;
	private int portfolioId;
}
