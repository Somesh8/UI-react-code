package com.finance.asset.AssetService.service;

import java.util.List;

import com.finance.asset.AssetService.Asset;

public interface AssetService {

	List<Asset> getAssetByPortId(int pId);

	Asset save(Asset data);

}
