package com.finance.asset.AssetService.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.finance.asset.AssetService.Asset;

@Repository
public interface AssetRepository extends JpaRepository<Asset, Integer>{

	List<Asset> findByPortfolioId(int pId);

}
