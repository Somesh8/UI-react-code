package com.finance.asset.AssetService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.finance.asset.AssetService.Asset;
import com.finance.asset.AssetService.service.AssetService;

@RestController
@RequestMapping("/asset")
public class AssetController {

	@Autowired
	private AssetService assetService;
	

	@GetMapping("/port/{pId}")
	List<Asset> getAssetByPortfolio(final int pId) {
		return assetService.getAssetByPortId(pId);
	}
	
	@PostMapping()
	Asset saveAsset(@RequestBody Asset data) {
		return assetService.save(data);
	}
	
}
