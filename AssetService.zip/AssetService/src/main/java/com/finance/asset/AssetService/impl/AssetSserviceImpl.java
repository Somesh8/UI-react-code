package com.finance.asset.AssetService.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.finance.asset.AssetService.Asset;
import com.finance.asset.AssetService.repository.AssetRepository;
import com.finance.asset.AssetService.service.AssetService;

@Service
public class AssetSserviceImpl implements AssetService {

	@Autowired
	private AssetRepository assetRepo;
	
	@Override
	public List<Asset> getAssetByPortId(int pId) {
		return assetRepo.findByPortfolioId(pId);
	}

	@Override
	public Asset save(Asset data) {
		// TODO Auto-generated method stub
		return assetRepo.save(data);
	}

}
