import './App.css';
import ListAsset from './Component/ListAsset';
import Header from './Header/Header';
import React from 'react';
const assets = [
  {
      id: 1,
      quantity: 5,
      type: "STOCK",
      price: 500.00,
      date: "01-02-2011",
      portfolioId: 1
  },
  {
      id:2,
      quantity:10,
      type: "BOND",
      price: 5000.00,
      date: "01-02-2012",
      portfolioId:2
  },
  {
      id:3,
      quantity:50,
      type: "Other",
      price: 120.00,
      date: "01-02-2022",
      portfolioId:3
  }
  ,
  {
      id:4,
      quantity:41,
      type: "Other",
      price: 100.00,
      date: "01-02-2012",
      portfolioId:1
  }
  ,
  {
      id:5,
      quantity:7,
      type: "STOCK",
      price: 70.00,
      date: "01-02-2012",
      portfolioId:2
  }
  ,
  {
      id:6,
      quantity:6,
      type: "BOND",
      price: 250.00,
      date: "01-02-2012",
      portfolioId:2
  }
  ,
  {
      id:7,
      quantity:2,
      type: "STOCK",
      price: 150.00,
      date: "01-02-2012",
      portfolioId:1
  }

];

function App() {
  const [listData, setListData] = React.useState(assets);
  const getSelectedValue = (index) => { 
    console.log(index);
    if(index=="STOCK") {
      let list= assets.filter((i) => i.type=="STOCK");
      setListData(list);
      console.log(list);
    }
    else if(index=="BOND") {
      let list= assets.filter((i) => (i.type=="BOND"));
      setListData(list);
      console.log(list);
    }
    else if(index=="ALL") {
      setListData(assets);
    }  
    else {
      let list= assets.filter((i) => (i.type!="STOCK" && i.type!="BOND" ));
      setListData(list);
      console.log(list);
    }
  };


  return (
    <>
      <Header getSelectedValue={getSelectedValue} />

    <div className="App container">
      <ListAsset listData={listData} />
    </div>
    </>
  );
}

export default App;
