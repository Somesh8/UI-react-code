
export default function ListAsset(props) {

    return (
        <>
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Id</th>
                        <th scope="col">Type</th>
                        <th scope="col">Date</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Price</th>
                        <th scope="col">Portfolio Id</th>
                    </tr>
                </thead>
                <tbody>
                    {props.listData.map((t) => (
                        <tr>
                            <th scope="row">{t.id}</th>
                            <td>{t.type}</td>
                            <td>{t.date}</td>
                            <td>{t.quantity}</td>
                            <td>{t.price}</td>
                            <td>{t.portfolioId}</td>
                        </tr>
                    )
                    )}
                </tbody>
            </table>
        </>
    )
}