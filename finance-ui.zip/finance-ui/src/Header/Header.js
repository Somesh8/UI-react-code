
export default function Header({ getSelectedValue }) {

  

  return (
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">Finance</a>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a class="nav-link" href="#" onClick={() => {
              getSelectedValue("ALL");
            }} >All Assets</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#"  onClick={() => {
              getSelectedValue("STOCK");
            }}><span class="sr-only" >(current)</span> Stock</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#" onClick={() => {
              getSelectedValue("BOND");
            }} >Asset</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#" onClick={() => {
              getSelectedValue("Other");
            }} >Others</a>
        </li>
      </ul>
    </div>
  </nav>
  )
}